plugins {
            id("com.android.application") version "8.5.0" apply false
            id("org.jetbrains.kotlin.android") version "2.0.20" apply false
            id("org.jetbrains.kotlin.plugin.compose") version "2.0.20" apply false
            id("com.google.dagger.hilt.android") version "2.48" apply false
        }



