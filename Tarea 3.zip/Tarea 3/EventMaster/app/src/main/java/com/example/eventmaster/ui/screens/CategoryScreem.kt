package com.example.eventmaster.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.eventmaster.ui.navigation.Routes
import com.example.eventmaster.viewmodel.CategoryViewModel

@Composable
fun CategoryScreen(navController: NavController, categoryId: Int, viewModel: CategoryViewModel) {

    val events by viewModel
        .getEventsByCategory(categoryId)
        .observeAsState(initial = emptyList<EventData>())

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        Button(onClick = {
            navController.navigate(Routes.CreateEvent + "/$categoryId")
        }) {
            Text("Crear Evento")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(events) { event ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(event.nombre)
                        Text(event.descripcion)
                        Text(event.fecha)
                    }
                }
            }
        }
    }
}