package com.example.eventmaster

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.eventmaster.ui.navigation.Routes
import com.example.eventmaster.ui.screens.HomeScreen
import com.example.eventmaster.ui.screens.CreateCategory
import com.example.eventmaster.ui.screens.CategoryScreen
import com.example.eventmaster.ui.screens.CreateEvent
import com.example.eventmaster.ui.screens.EventScreen
import com.example.eventmaster.viewmodel.CategoryViewModel

@Composable
fun Navigation() {
    val navController = rememberNavController()
    val categoryViewModel: CategoryViewModel = hiltViewModel()

    NavHost(navController = navController, startDestination = Routes.HomeScreen) {

        composable(Routes.HomeScreen) {
            HomeScreen(navController, categoryViewModel)
        }
        composable(Routes.CreateCategory) {
            CreateCategory(navController, categoryViewModel)
        }
        composable(Routes.Category + "/{categoryId}") { backStackEntry ->
            val categoryId = backStackEntry.arguments?.getString("categoryId")?.toIntOrNull()
            if (categoryId != null) CategoryScreen(navController, categoryId, categoryViewModel)
        }
        composable(Routes.CreateEvent + "/{categoryId}") { backStackEntry ->
            val categoryId = backStackEntry.arguments?.getString("categoryId")?.toIntOrNull()
            if (categoryId != null) CreateEvent(navController, categoryViewModel, categoryId)
        }
        composable(Routes.Event + "/{categoryId}" + "/{eventId}") { backStackEntry ->
            val categoryId = backStackEntry.arguments?.getString("categoryId")?.toIntOrNull()
            val eventId = backStackEntry.arguments?.getString("eventId")?.toIntOrNull()
            if (categoryId != null && eventId != null) EventScreen(navController, categoryViewModel, categoryId, eventId)
        }
    }
}