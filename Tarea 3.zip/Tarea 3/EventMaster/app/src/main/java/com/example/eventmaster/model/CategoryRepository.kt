package com.example.eventmaster

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.eventmaster.ui.navigation.Routes
//import com.example.eventmaster.ui.screens.Category
import com.example.eventmaster.ui.screens.HomeScreen
import com.example.eventmaster.ui.screens.CreateCategory
//import com.example.eventmaster.ui.screens.CreateEvent
//import com.example.eventmaster.ui.screens.Event
import com.example.eventmaster.viewmodel.CategoryViewModel



@Composable
fun Navigations(){
    val navController = rememberNavController()
    val categoryViewModel: CategoryViewModel = viewModel()

    NavHost(navController = navController, startDestination = Routes.HomeScreen, builder = {
        composable(Routes.HomeScreen){
            HomeScreen(navController,categoryViewModel)
        }
        composable(Routes.CreateCategory){
            CreateCategory(navController,categoryViewModel)
        }

    })
}

