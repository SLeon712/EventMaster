package com.example.eventmaster.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(
    foreignKeys = [ForeignKey(
        entity = CategoryData::class,
        parentColumns = ["id"],
        childColumns = ["categoryId"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class EventData(
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0,
    var categoryId: Int,
    var nombre: String,
    var descripcion: String,
    var fecha: String,
    var iconoId: Int
)