package com.example.eventmaster.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.eventmaster.db.CategoryDao
import com.example.eventmaster.db.EventDao
import com.example.eventmaster.model.CategoryData
import com.example.eventmaster.model.EventData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel                              // ← agregar
class CategoryViewModel @Inject constructor( // ← agregar
    private val categoryDao: CategoryDao,
    private val eventDao: EventDao
) : ViewModel() {

    val categoriesList: LiveData<List<CategoryData>> = categoryDao.getAllCategories()

    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    fun addCategory(nombre: String, descripcion: String, iconoId: Int) {
        _isLoading.postValue(true)
        viewModelScope.launch(Dispatchers.IO) {
            categoryDao.addCategories(
                CategoryData(nombre = nombre, descripcion = descripcion, iconoId = iconoId)
            )
            _isLoading.postValue(false)
        }
    }

    fun getEventsForCategory(categoryId: Int): LiveData<List<EventData>> {
        return eventDao.getEventsByCategory(categoryId)
    }

    fun addEvent(categoryId: Int, nombre: String, descripcion: String, fecha: String, iconoId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            eventDao.addEvent(
                EventData(
                    categoryId = categoryId,
                    nombre = nombre,
                    descripcion = descripcion,
                    fecha = fecha,
                    iconoId = iconoId
                )
            )
        }
    }
}