package com.example.eventmaster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.eventmaster.R
import com.example.eventmaster.model.CategoryData
import com.example.eventmaster.ui.navigation.Routes
import com.example.eventmaster.viewmodel.CategoryViewModel

@Composable
fun CreateCategory(
    navController: NavController,
    categoryViewModel: CategoryViewModel
){

    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }

    val icons = listOf(
        R.drawable.clock,
        R.drawable.image,
        R.drawable.spotify,
        R.drawable.youtube,
        R.drawable.whatsapp
    )

    var selectIcon by remember { mutableStateOf(icons.first()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primary),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text("Nueva Categoria", fontSize = 28.sp, color = Color.White)

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = descripcion,
            onValueChange = { descripcion = it },
            label = { Text("Descripcion") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(icons) { icon ->
                val isSelected = selectIcon == icon

                IconButton(
                    onClick = { selectIcon = icon },
                    modifier = Modifier
                        .size(60.dp)
                        .background(
                            color = if (isSelected)
                                MaterialTheme.colorScheme.inversePrimary
                            else Color(0x33000000),
                            shape = RoundedCornerShape(50)
                        )
                ) {
                    Icon(
                        painter = painterResource(id = icon),
                        contentDescription = null,
                        tint = if (isSelected) Color.White else Color(0xFFFFDCC4)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                categoryViewModel.insert(
                    CategoryData(
                        nombre = nombre,
                        descripcion = descripcion,
                        iconoId = selectIcon
                    )
                )
                navController.popBackStack()
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.inversePrimary
            )
        ) {
            Text("Crear Nueva categoria")
        }
    }
}