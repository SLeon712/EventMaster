package com.example.eventmaster.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.eventmaster.model.CategoryData
import java.util.Locale

@Dao
interface CategoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: CategoryData)

    @Update
    suspend fun updateCategory(category: CategoryData)

    @Delete
    suspend fun deleteCategory(category: CategoryData)

    @Query("SELECT * FROM categories")
    fun getAllCategories(): LiveData<List<CategoryData>>
}