package com.example.eventmaster.viewmodel

import androidx.lifecycle.*
import com.example.eventmaster.model.CategoryData
import com.example.eventmaster.model.CategoryRepository
import kotlinx.coroutines.launch

class CategoryViewModel(private val repository: CategoryRepository) : ViewModel() {

    val categories: LiveData<List<CategoryData>> = repository.categories

    fun insert(category: CategoryData) {
        viewModelScope.launch {
            repository.insert(category)
        }
    }
}