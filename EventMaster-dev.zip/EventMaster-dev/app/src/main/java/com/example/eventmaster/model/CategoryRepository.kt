package com.example.eventmaster.model

import androidx.lifecycle.LiveData
import com.example.eventmaster.db.CategoryDao

class CategoryRepository(private val dao: CategoryDao) {

    val categories: LiveData<List<CategoryData>> = dao.getAllCategories()

    suspend fun insert(category: CategoryData) {
        dao.insertCategory(category)
    }

    suspend fun update(category: CategoryData) {
        dao.updateCategory(category)
    }

    suspend fun delete(category: CategoryData) {
        dao.deleteCategory(category)
    }
}