package com.example.eventmaster.model

import androidx.lifecycle.LiveData
import com.example.eventmaster.db.EventDao

class EventRepository(private val dao: EventDao) {

    val events: LiveData<List<EventData>> = dao.getAllEvents()

    suspend fun insert(event: EventData) {
        dao.insertEvent(event)
    }
}