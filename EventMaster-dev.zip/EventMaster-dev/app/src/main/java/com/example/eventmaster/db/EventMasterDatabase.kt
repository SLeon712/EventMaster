package com.example.eventmaster.db

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.eventmaster.model.CategoryData
import com.example.eventmaster.model.EventData
import androidx.room.Room

@Database(entities = [CategoryData::class , EventData::class], version = 1)
abstract class EventMasterDatabase : RoomDatabase(){
    companion object {
        const val NAME = "EventMaster_DB"

        @Volatile
        private var INSTANCE: EventMasterDatabase? = null

        fun getDatabase(context: Context): EventMasterDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EventMasterDatabase::class.java,
                    NAME
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }

    abstract fun getCategoryDao() : CategoryDao
    abstract fun getEventDao(): EventDao
}

