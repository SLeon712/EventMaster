package com.example.eventmaster.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.eventmaster.db.EventMasterDatabase
import com.example.eventmaster.model.EventData
import com.example.eventmaster.model.EventRepository
import com.example.eventmaster.viewmodel.EventViewModel
import com.example.eventmaster.viewmodel.EventViewModelFactory

@Composable
fun CreateEvent(
    navController: NavController,
    categoryId: Int
) {

    val context = LocalContext.current
    val db = EventMasterDatabase.getDatabase(context)
    val repository = EventRepository(db.getEventDao())
    val factory = EventViewModelFactory(repository)

    val viewModel: EventViewModel = viewModel(factory = factory)

    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var organizador by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primary),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "Nuevo Evento",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        TextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Nombre") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        TextField(
            value = descripcion,
            onValueChange = { descripcion = it },
            label = { Text("Descripción") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        TextField(
            value = organizador,
            onValueChange = { organizador = it },
            label = { Text("Organizador") }
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (error.isNotEmpty()) {
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error
            )
        }

        Button(
            onClick = {

                if (nombre.isEmpty() || descripcion.isEmpty() || organizador.isEmpty()) {
                    error = "Todos los campos son obligatorios"
                    return@Button
                }

                val event = EventData(
                    nombre = nombre,
                    descripcion = descripcion,
                    organizador = organizador,
                    categoryId = categoryId
                )

                viewModel.insert(event)
                navController.popBackStack()
            }
        ) {
            Text("Crear Evento")
        }
    }
}