package com.example.eventmaster.viewmodel

import androidx.lifecycle.*
import com.example.eventmaster.model.EventData
import com.example.eventmaster.model.EventRepository
import kotlinx.coroutines.launch

class EventViewModel(private val repository: EventRepository) : ViewModel() {

    val events = repository.events

    fun insert(event: EventData) {
        viewModelScope.launch {
            repository.insert(event)
        }
    }
}